//
//  File.swift
//  entregableIOS
//
//  Created by SP 23 on 17/5/18.
//  Copyright © 2018 UCUDAL. All rights reserved.
//

import Foundation
import ObjectMapper
import MapKit


class ATR: Mappable {
    var id: Int?
    var location: location?
    var address: String?
    var network: String?
    var status: String?
    var hasMoney: Bool?
    var acceptsDeposits: Bool?
    var imageUrl: String?
    var openHours: String?
    
    required init?(map: Map){
        
    }
    init() {
        
    }
    func mapping(map: Map) {
        id <- map["id"]
        location <- map["location"]
        address <- map["address"]
        network <- map["network"]
        status <- map["status"]
        hasMoney <- map["has_money"]
        acceptsDeposits <- map["accepts_deposits"]
        imageUrl <- map["image_url"]
        openHours <- map["open_hours"]
    }
}

class location: Mappable{
    var lat: Double?
    var lon: Double?
    
    
    required init?(map: Map){
        
    }
    
    func mapping(map: Map) {
        lat <- map["lat"]
        lon <- map["lon"]
    }
}




