//
//  DetailsViewController.swift
//  entregableIOS
//
//  Created by SP 23 on 24/5/18.
//  Copyright © 2018 UCUDAL. All rights reserved.
//

import Foundation
import UIKit

class DetailViewControler: UIViewController{
    @IBOutlet weak var labelAddress: UILabel!
    @IBOutlet weak var labelOpenHours: UILabel!
    @IBOutlet weak var labelHasMoney: UILabel!
    @IBOutlet weak var labelAcceptsDeposits: UILabel!
    @IBOutlet weak var backgroundImg: UIImageView!
    @IBOutlet weak var networkImg: UIImageView!
    
    
    var ATM: ATR?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        labelAddress.text = ATM?.address
        labelOpenHours.text = ATM?.openHours
        if ATM?.hasMoney == true{
            labelHasMoney.text = "Has money"
        }else{
            labelHasMoney.text = "Don't has money"
        }
        
        if ATM?.acceptsDeposits == true{
             labelAcceptsDeposits.text = "Accepts deposits"
        }else{
            labelAcceptsDeposits.text = "Don't accepts deposits"
        }
        
        let image = ATM?.imageUrl
        print(image!)
        let url = URL(string: image!)
        let data = try? Data(contentsOf: url!)
        
        if let imageData = data {
            backgroundImg.image = UIImage(data: imageData)
        }
        
        if ATM?.network == "RedBROU"{
            networkImg.image = UIImage(named: "redbrou")
        }else if ATM?.network == "Banred"{
            networkImg.image = UIImage(named: "banred")
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
