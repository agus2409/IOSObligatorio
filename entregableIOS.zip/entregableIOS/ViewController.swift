//
//  ViewController.swift
//  entregableIOS
//
//  Created by SP 23 on 17/5/18.
//  Copyright © 2018 UCUDAL. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit


class ViewController: UIViewController,CLLocationManagerDelegate,MKMapViewDelegate{
    @IBOutlet weak var map: MKMapView!
    
    
    let locationManager = CLLocationManager()
    
    var selectedATM: ATR?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // For use in foreground
        self.locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.startUpdatingLocation()
        }
        
        map.delegate = self
        map.mapType = .standard
        map.isZoomEnabled = false
        map.isScrollEnabled = true
        
        if let coor = map.userLocation.location?.coordinate{
            map.setCenter(coor, animated: true)
        }
        
        Model.mapObjects()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locvalue:CLLocationCoordinate2D = (locations.first?.coordinate)!
        let span = MKCoordinateSpanMake(10, 10)
        let region = MKCoordinateRegion(center: locvalue, span: span)
        
        
        map.mapType = MKMapType.standard
        map.setRegion(region, animated: true)
        map.isZoomEnabled = true
        
        
        for ATM in Model.ATMArray{
            let lat = ATM.location?.lat
            let lon = ATM.location?.lon
            
            let annotation = MKPointAnnotation()
            annotation.coordinate = CLLocationCoordinate2D(latitude: lat!, longitude: lon!)
            annotation.title = ATM.address
            map.addAnnotation(annotation)
        }
        
        map.setCenter(locvalue, animated: true)
    }
    
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        selectedATM = ATMSelected(annotation: view.annotation as! MKPointAnnotation)
        performSegue(withIdentifier: "ATMDetailSegue", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let DetailViewControler = segue.destination as? DetailViewControler {
            DetailViewControler.ATM = selectedATM
        }
    }
    
}




