//
//  Model.swift
//  entregableIOS
//
//  Created by SP 23 on 23/5/18.
//  Copyright © 2018 UCUDAL. All rights reserved.
//

import Foundation
import AlamofireObjectMapper
import Alamofire
import MapKit

class Model{
    static var ATMArray = Array<ATR>()
    static let model = Model()
    
    
    init() {
    }
    
    static func mapObjects(){
        let URL = "http://ucu-atm.herokuapp.com/api/atm"
        Alamofire.request(URL).responseArray{ (response: DataResponse<[ATR]>) in
            if let auxATMArray = response.result.value{
                ATMArray = auxATMArray
            }
        }
    }
    
    
    
}

func ATMSelected(annotation: MKPointAnnotation) -> ATR?{
    var ATM:ATR?
    for auxATM in Model.ATMArray{
        if annotation.coordinate.latitude == auxATM.location?.lat{
            if annotation.coordinate.longitude == auxATM.location?.lon{
                if annotation.title == auxATM.address{
                    ATM = auxATM
                }
            }
        }
    }
    return ATM
}

